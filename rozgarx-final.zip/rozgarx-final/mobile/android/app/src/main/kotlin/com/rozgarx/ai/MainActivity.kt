package com.rozgarx.ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
