import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class PremiumLockWidget extends StatelessWidget {
  final String feature;
  final Widget child;
  final bool isLocked;

  const PremiumLockWidget({
    super.key,
    required this.feature,
    required this.child,
    this.isLocked = true,
  });

  @override
  Widget build(BuildContext context) {
    if (!isLocked) return child;
    return GestureDetector(
      onTap: () => context.push('/premium'),
      child: Stack(
        children: [
          AbsorbPointer(child: Opacity(opacity: 0.4, child: child)),
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.85),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.lock, color: Color(0xFF1A73E8), size: 28),
                  const SizedBox(height: 6),
                  Text(
                    'Unlock $feature',
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF202124),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1A73E8),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: const Text('Upgrade', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
