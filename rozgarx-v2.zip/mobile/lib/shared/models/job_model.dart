import 'package:cloud_firestore/cloud_firestore.dart';

class JobModel {
  final String id;
  final String title;
  final String organization;
  final String category;
  final int totalVacancies;
  final String salaryMin;
  final String salaryMax;
  final DateTime? applicationStart;
  final DateTime? applicationEnd;
  final String? examDate;
  final String eligibility;
  final String ageLimit;
  final double applicationFee;
  final String officialUrl;
  final String? pdfUrl;
  final String state;
  final String competitionLevel;
  final double difficultyScore;
  final bool isActive;
  final bool isSaved;
  final DateTime? lastViewedAt;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String? aiSummary;

  const JobModel({
    required this.id,
    required this.title,
    required this.organization,
    required this.category,
    required this.totalVacancies,
    required this.salaryMin,
    required this.salaryMax,
    this.applicationStart,
    this.applicationEnd,
    this.examDate,
    required this.eligibility,
    required this.ageLimit,
    required this.applicationFee,
    required this.officialUrl,
    this.pdfUrl,
    required this.state,
    required this.competitionLevel,
    required this.difficultyScore,
    required this.isActive,
    this.isSaved = false,
    this.lastViewedAt,
    required this.createdAt,
    required this.updatedAt,
    this.aiSummary,
  });

  factory JobModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return JobModel(
      id: doc.id,
      title: data['title'] as String? ?? '',
      organization: data['organization'] as String? ?? '',
      category: data['category'] as String? ?? '',
      totalVacancies: (data['totalVacancies'] as num?)?.toInt() ?? 0,
      salaryMin: data['salaryMin'] as String? ?? '',
      salaryMax: data['salaryMax'] as String? ?? '',
      applicationStart: (data['applicationStart'] as Timestamp?)?.toDate(),
      applicationEnd: (data['applicationEnd'] as Timestamp?)?.toDate(),
      examDate: data['examDate'] as String?,
      eligibility: data['eligibility'] as String? ?? '',
      ageLimit: data['ageLimit'] as String? ?? '',
      applicationFee: (data['applicationFee'] as num?)?.toDouble() ?? 0,
      officialUrl: data['officialUrl'] as String? ?? '',
      pdfUrl: data['pdfUrl'] as String?,
      state: data['state'] as String? ?? 'All India',
      competitionLevel: data['competitionLevel'] as String? ?? 'Medium',
      difficultyScore: (data['difficultyScore'] as num?)?.toDouble() ?? 5.0,
      isActive: data['isActive'] as bool? ?? true,
      isSaved: data['isSaved'] as bool? ?? false,
      lastViewedAt: (data['lastViewedAt'] as Timestamp?)?.toDate(),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      aiSummary: data['aiSummary'] as String?,
    );
  }

  Map<String, dynamic> toMap() => {
    'title': title,
    'organization': organization,
    'category': category,
    'totalVacancies': totalVacancies,
    'salaryMin': salaryMin,
    'salaryMax': salaryMax,
    'applicationStart': applicationStart != null ? Timestamp.fromDate(applicationStart!) : null,
    'applicationEnd': applicationEnd != null ? Timestamp.fromDate(applicationEnd!) : null,
    'examDate': examDate,
    'eligibility': eligibility,
    'ageLimit': ageLimit,
    'applicationFee': applicationFee,
    'officialUrl': officialUrl,
    'pdfUrl': pdfUrl,
    'state': state,
    'competitionLevel': competitionLevel,
    'difficultyScore': difficultyScore,
    'isActive': isActive,
    'isSaved': isSaved,
    'lastViewedAt': lastViewedAt != null ? Timestamp.fromDate(lastViewedAt!) : null,
    'createdAt': Timestamp.fromDate(createdAt),
    'updatedAt': Timestamp.fromDate(updatedAt),
    'aiSummary': aiSummary,
  };

  JobModel copyWith({
    String? id, String? title, String? organization, String? category,
    int? totalVacancies, String? salaryMin, String? salaryMax,
    DateTime? applicationStart, DateTime? applicationEnd, String? examDate,
    String? eligibility, String? ageLimit, double? applicationFee,
    String? officialUrl, String? pdfUrl, String? state,
    String? competitionLevel, double? difficultyScore, bool? isActive,
    bool? isSaved, DateTime? lastViewedAt, DateTime? createdAt,
    DateTime? updatedAt, String? aiSummary,
  }) => JobModel(
    id: id ?? this.id,
    title: title ?? this.title,
    organization: organization ?? this.organization,
    category: category ?? this.category,
    totalVacancies: totalVacancies ?? this.totalVacancies,
    salaryMin: salaryMin ?? this.salaryMin,
    salaryMax: salaryMax ?? this.salaryMax,
    applicationStart: applicationStart ?? this.applicationStart,
    applicationEnd: applicationEnd ?? this.applicationEnd,
    examDate: examDate ?? this.examDate,
    eligibility: eligibility ?? this.eligibility,
    ageLimit: ageLimit ?? this.ageLimit,
    applicationFee: applicationFee ?? this.applicationFee,
    officialUrl: officialUrl ?? this.officialUrl,
    pdfUrl: pdfUrl ?? this.pdfUrl,
    state: state ?? this.state,
    competitionLevel: competitionLevel ?? this.competitionLevel,
    difficultyScore: difficultyScore ?? this.difficultyScore,
    isActive: isActive ?? this.isActive,
    isSaved: isSaved ?? this.isSaved,
    lastViewedAt: lastViewedAt ?? this.lastViewedAt,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
    aiSummary: aiSummary ?? this.aiSummary,
  );

  bool get isClosingSoon {
    if (applicationEnd == null) return false;
    final days = applicationEnd!.difference(DateTime.now()).inDays;
    return days <= 3 && days >= 0;
  }

  bool get isExpired {
    if (applicationEnd == null) return false;
    return DateTime.now().isAfter(applicationEnd!);
  }

  int get daysRemaining {
    if (applicationEnd == null) return 999;
    return applicationEnd!.difference(DateTime.now()).inDays;
  }

  String get salaryDisplay => salaryMax.isNotEmpty ? '₹$salaryMin - ₹$salaryMax' : salaryMin.isNotEmpty ? '₹$salaryMin' : 'As per post';
}
