import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../../features/auth/screens/splash_screen.dart';
import '../../features/auth/screens/login_screen.dart';
import '../../features/auth/screens/onboarding_screen.dart';
import '../../features/dashboard/screens/dashboard_screen.dart';
import '../../features/jobs/screens/jobs_list_screen.dart';
import '../../features/jobs/screens/job_detail_screen.dart';
import '../../features/preparation/screens/study_plan_screen.dart';
import '../../features/profile/screens/profile_screen.dart';
import '../../features/premium/screens/premium_screen.dart';
import '../../features/apply/screens/ad_unlock_screen.dart';
import '../../features/apply/screens/apply_assistance_screen.dart';
import '../../shared/widgets/main_shell.dart';

final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/splash',
    redirect: (context, state) {
      final user = FirebaseAuth.instance.currentUser;
      final loc = state.matchedLocation;
      final publicRoutes = ['/splash', '/login', '/onboarding'];
      if (publicRoutes.contains(loc)) return null;
      if (user == null) return '/login';
      return null;
    },
    routes: [
      GoRoute(path: '/splash', builder: (c, s) => const SplashScreen()),
      GoRoute(path: '/login', builder: (c, s) => const LoginScreen()),
      GoRoute(path: '/onboarding', builder: (c, s) => const OnboardingScreen()),
      GoRoute(path: '/premium', builder: (c, s) => const PremiumScreen()),
      GoRoute(
        path: '/ad-unlock',
        builder: (c, s) => AdUnlockScreen(
          feature: s.uri.queryParameters['feature'] ?? 'feature',
        ),
      ),
      GoRoute(
        path: '/apply-assistance',
        builder: (c, s) => ApplyAssistanceScreen(
          jobId: s.uri.queryParameters['jobId'] ?? '',
          jobTitle: Uri.decodeComponent(s.uri.queryParameters['jobTitle'] ?? ''),
        ),
      ),
      ShellRoute(
        builder: (c, s, child) => MainShell(child: child),
        routes: [
          GoRoute(path: '/', builder: (c, s) => const DashboardScreen()),
          GoRoute(
            path: '/jobs',
            builder: (c, s) => const JobsListScreen(),
            routes: [
              GoRoute(
                path: ':jobId',
                builder: (c, s) => JobDetailScreen(jobId: s.pathParameters['jobId']!),
              ),
            ],
          ),
          GoRoute(path: '/preparation', builder: (c, s) => const StudyPlanScreen()),
          GoRoute(path: '/profile', builder: (c, s) => const ProfileScreen()),
        ],
      ),
    ],
    errorBuilder: (c, s) => Scaffold(
      body: Center(child: Text('Page not found: ${s.matchedLocation}')),
    ),
  );
});
