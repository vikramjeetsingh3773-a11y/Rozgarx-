import 'package:cloud_firestore/cloud_firestore.dart';
import '../../../shared/models/job_model.dart';
import '../../../core/cache/cache_service.dart';

class JobRepository {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  final CacheService _cache;

  JobRepository(this._cache);

  Stream<List<JobModel>> getActiveJobs() => _db
      .collection('jobs')
      .where('isActive', isEqualTo: true)
      .orderBy('applicationEnd')
      .snapshots()
      .map((s) => s.docs.map((d) => JobModel.fromFirestore(d)).toList());

  Stream<List<JobModel>> getJobsByCategory(String category) => _db
      .collection('jobs')
      .where('isActive', isEqualTo: true)
      .where('category', isEqualTo: category)
      .orderBy('applicationEnd')
      .snapshots()
      .map((s) => s.docs.map((d) => JobModel.fromFirestore(d)).toList());

  Stream<List<JobModel>> getClosingSoonJobs() {
    final weekLater = DateTime.now().add(const Duration(days: 7));
    return _db
        .collection('jobs')
        .where('isActive', isEqualTo: true)
        .where('applicationEnd', isGreaterThanOrEqualTo: Timestamp.now())
        .where('applicationEnd', isLessThanOrEqualTo: Timestamp.fromDate(weekLater))
        .orderBy('applicationEnd')
        .snapshots()
        .map((s) => s.docs.map((d) => JobModel.fromFirestore(d)).toList());
  }

  Future<JobModel?> getJobById(String jobId) async {
    try {
      final doc = await _db.collection('jobs').doc(jobId).get();
      if (!doc.exists) return null;
      return JobModel.fromFirestore(doc);
    } catch (e) {
      return null;
    }
  }

  Future<List<JobModel>> searchJobs(String query) async {
    try {
      final snap = await _db.collection('jobs').where('isActive', isEqualTo: true).get();
      final q = query.toLowerCase();
      return snap.docs
          .map((d) => JobModel.fromFirestore(d))
          .where((j) => j.title.toLowerCase().contains(q) || j.organization.toLowerCase().contains(q) || j.category.toLowerCase().contains(q))
          .toList();
    } catch (e) {
      return [];
    }
  }

  Future<List<JobModel>> getSavedJobs() async {
    final ids = _cache.getSavedJobIds();
    if (ids.isEmpty) return [];
    final jobs = <JobModel>[];
    for (final id in ids) {
      final j = await getJobById(id);
      if (j != null) jobs.add(j);
    }
    return jobs;
  }

  Future<void> toggleSaveJob(String jobId) async {
    if (_cache.isJobSaved(jobId)) {
      await _cache.unsaveJob(jobId);
    } else {
      await _cache.saveJob(jobId);
    }
  }

  bool isJobSaved(String jobId) => _cache.isJobSaved(jobId);
}
