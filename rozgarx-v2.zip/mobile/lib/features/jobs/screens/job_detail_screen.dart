import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:go_router/go_router.dart';
import '../../../shared/models/job_model.dart';

class JobDetailScreen extends StatefulWidget {
  final String jobId;
  const JobDetailScreen({super.key, required this.jobId});
  @override
  State<JobDetailScreen> createState() => _JobDetailScreenState();
}

class _JobDetailScreenState extends State<JobDetailScreen> {
  JobModel? _job;
  bool _loading = true;

  @override
  void initState() { super.initState(); _loadJob(); }

  Future<void> _loadJob() async {
    try {
      final doc = await FirebaseFirestore.instance.collection('jobs').doc(widget.jobId).get();
      if (doc.exists && mounted) setState(() { _job = JobModel.fromFirestore(doc); _loading = false; });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        backgroundColor: Colors.white, elevation: 0,
        leading: IconButton(icon: const Icon(Icons.arrow_back, color: Color(0xFF202124)), onPressed: () => context.pop()),
        title: Text(_job?.organization ?? 'Job Detail', style: const TextStyle(color: Color(0xFF202124), fontSize: 14, fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(icon: const Icon(Icons.share_outlined, color: Color(0xFF202124)), onPressed: () {}),
          IconButton(icon: const Icon(Icons.bookmark_border, color: Color(0xFF202124)), onPressed: () {}),
        ],
      ),
      body: _loading ? const Center(child: CircularProgressIndicator()) : _job == null ? const Center(child: Text('Job not found')) : _buildBody(_job!),
    );
  }

  Widget _buildBody(JobModel job) {
    return Column(children: [
      Expanded(
        child: SingleChildScrollView(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(color: Colors.white, padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              _CatBadge(cat: job.category),
              const SizedBox(height: 8),
              Text(job.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Color(0xFF202124))),
              const SizedBox(height: 4),
              Text('${job.organization} • ${job.state}', style: const TextStyle(fontSize: 12, color: Color(0xFF5F6368))),
              const SizedBox(height: 10),
              Wrap(spacing: 6, runSpacing: 4, children: [
                _Pill('👥 ${job.totalVacancies} Vacancies', const Color(0xFFE8F0FE), const Color(0xFF1A73E8)),
                _Pill('₹ ${job.salaryDisplay}', const Color(0xFFE6F4EA), const Color(0xFF34A853)),
                if (job.applicationFee == 0) _Pill('Free Application', const Color(0xFFE6F4EA), const Color(0xFF34A853)) else _Pill('Fee: ₹${job.applicationFee.toInt()}', const Color(0xFFFCE8E6), const Color(0xFFEA4335)),
              ]),
            ])),
            const SizedBox(height: 6),
            if (job.aiSummary != null) ...[
              Container(color: Colors.white, padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Row(children: [Text('🤖 ', style: TextStyle(fontSize: 14)), Text('AI Summary', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Color(0xFF202124)))]),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(color: const Color(0xFFE8F0FE), borderRadius: BorderRadius.circular(8)),
                  child: Text(job.aiSummary!, style: const TextStyle(fontSize: 12, color: Color(0xFF202124), height: 1.5)),
                ),
              ])),
              const SizedBox(height: 6),
            ],
            Container(color: Colors.white, padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('📅 Important Dates', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Color(0xFF202124))),
              const SizedBox(height: 10),
              _DateRow('Application Start', _fmt(job.applicationStart)),
              _DateRow('Last Date', _fmt(job.applicationEnd), urgent: job.isClosingSoon),
              if (job.examDate != null) _DateRow('Exam Date', job.examDate!),
            ])),
            const SizedBox(height: 6),
            Container(color: Colors.white, padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('✅ Eligibility', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Color(0xFF202124))),
              const SizedBox(height: 10),
              _InfoRow('Education', job.eligibility),
              _InfoRow('Age Limit', job.ageLimit),
              _InfoRow('Application Fee', job.applicationFee == 0 ? 'Free' : '₹${job.applicationFee.toInt()}'),
            ])),
            const SizedBox(height: 6),
            Container(color: Colors.white, padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('📊 Competition Analysis', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: Color(0xFF202124))),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: _AnalCard(label: 'Competition', value: job.competitionLevel, color: _compColor(job.competitionLevel))),
                const SizedBox(width: 8),
                Expanded(child: _AnalCard(label: 'Difficulty', value: '${job.difficultyScore}/10', color: const Color(0xFFF9AB00))),
              ]),
            ])),
            const SizedBox(height: 80),
          ]),
        ),
      ),
      Container(
        color: Colors.white, padding: const EdgeInsets.fromLTRB(12, 8, 12, 16),
        child: Row(children: [
          if (job.pdfUrl != null) ...[
            Expanded(child: OutlinedButton.icon(
              onPressed: () => context.push('/jobs/${job.id}/pdf?url=${Uri.encodeComponent(job.pdfUrl!)}&title=${Uri.encodeComponent(job.title)}'),
              icon: const Icon(Icons.picture_as_pdf, size: 16),
              label: const Text('PDF', style: TextStyle(fontSize: 12)),
              style: OutlinedButton.styleFrom(foregroundColor: const Color(0xFF1A73E8), side: const BorderSide(color: Color(0xFF1A73E8)), padding: const EdgeInsets.symmetric(vertical: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            )),
            const SizedBox(width: 8),
          ],
          Expanded(flex: 2, child: ElevatedButton.icon(
            onPressed: () => context.push('/apply-assistance?jobId=${job.id}&jobTitle=${Uri.encodeComponent(job.title)}'),
            icon: const Icon(Icons.open_in_new, size: 16),
            label: const Text('Apply Now', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1A73E8), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 10), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          )),
        ]),
      ),
    ]);
  }

  String _fmt(DateTime? d) => d == null ? 'TBA' : '${d.day}/${d.month}/${d.year}';
  Color _compColor(String l) { switch (l.toLowerCase()) { case 'extreme': return const Color(0xFFEA4335); case 'high': return const Color(0xFFF9AB00); default: return const Color(0xFF34A853); } }
}

class _CatBadge extends StatelessWidget {
  final String cat;
  const _CatBadge({required this.cat});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3), decoration: BoxDecoration(color: const Color(0xFFE8F0FE), borderRadius: BorderRadius.circular(6)), child: Text(cat.toUpperCase(), style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: Color(0xFF1A73E8), letterSpacing: 0.5)));
}

class _Pill extends StatelessWidget {
  final String t; final Color bg, fg;
  const _Pill(this.t, this.bg, this.fg);
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4), decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)), child: Text(t, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w600, color: fg)));
}

class _DateRow extends StatelessWidget {
  final String label, value; final bool urgent;
  const _DateRow(this.label, this.value, {this.urgent = false});
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
    Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFF5F6368))),
    Text(value, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: urgent ? const Color(0xFFEA4335) : const Color(0xFF202124))),
  ]));
}

class _InfoRow extends StatelessWidget {
  final String label, value;
  const _InfoRow(this.label, this.value);
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
    SizedBox(width: 110, child: Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFF5F6368)))),
    Expanded(child: Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Color(0xFF202124)))),
  ]));
}

class _AnalCard extends StatelessWidget {
  final String label, value; final Color color;
  const _AnalCard({required this.label, required this.value, required this.color});
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: color.withOpacity(0.08), borderRadius: BorderRadius.circular(10), border: Border.all(color: color.withOpacity(0.2))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(label, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w500, color: color)),
    const SizedBox(height: 4),
    Text(value, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: color)),
  ]));
}
