import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  int _step = 0;
  String? _education, _targetExam, _state, _stage;

  final _educationOptions = ['10th Pass', '12th Pass', 'Graduate', 'Post Graduate'];
  final _examOptions = ['SSC', 'Railway', 'Banking', 'UPSC', 'Police', 'Defence', 'State PSC'];
  final _stateOptions = ['All India', 'Uttar Pradesh', 'Bihar', 'Rajasthan', 'Madhya Pradesh', 'Maharashtra', 'Gujarat', 'Punjab', 'Haryana', 'Delhi', 'Other'];
  final _stageOptions = ['Just Starting', 'Preparing 6+ months', 'Appeared in exams', 'Working professional'];

  bool get _canProceed {
    switch (_step) {
      case 0: return _education != null;
      case 1: return _targetExam != null;
      case 2: return _state != null;
      case 3: return _stage != null;
      default: return false;
    }
  }

  void _next() {
    if (_step < 3) setState(() => _step++);
    else context.go('/');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              Row(children: List.generate(4, (i) => Expanded(
                child: Container(
                  height: 3,
                  margin: const EdgeInsets.only(right: 4),
                  decoration: BoxDecoration(
                    color: i <= _step ? const Color(0xFF1A73E8) : const Color(0xFFE8EAED),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ))),
              const SizedBox(height: 32),
              Expanded(child: _buildStep()),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _canProceed ? _next : null,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF1A73E8),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  child: Text(_step < 3 ? 'Continue →' : 'Get Started 🚀',
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStep() {
    switch (_step) {
      case 0: return _OptionStep(title: '🎓 Your Education', subtitle: 'Highest qualification', options: _educationOptions, selected: _education, onSelect: (v) => setState(() => _education = v));
      case 1: return _OptionStep(title: '🎯 Target Exam', subtitle: 'Which exam are you preparing for?', options: _examOptions, selected: _targetExam, onSelect: (v) => setState(() => _targetExam = v));
      case 2: return _OptionStep(title: '📍 Your State', subtitle: 'We will show relevant state jobs', options: _stateOptions, selected: _state, onSelect: (v) => setState(() => _state = v));
      case 3: return _OptionStep(title: '📊 Preparation Stage', subtitle: 'Where are you in your journey?', options: _stageOptions, selected: _stage, onSelect: (v) => setState(() => _stage = v));
      default: return const SizedBox();
    }
  }
}

class _OptionStep extends StatelessWidget {
  final String title, subtitle;
  final List<String> options;
  final String? selected;
  final ValueChanged<String> onSelect;
  const _OptionStep({required this.title, required this.subtitle, required this.options, required this.selected, required this.onSelect});

  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Color(0xFF202124))),
      const SizedBox(height: 6),
      Text(subtitle, style: const TextStyle(fontSize: 13, color: Color(0xFF5F6368))),
      const SizedBox(height: 20),
      Expanded(
        child: ListView.builder(
          itemCount: options.length,
          itemBuilder: (context, i) {
            final opt = options[i];
            final sel = opt == selected;
            return GestureDetector(
              onTap: () => onSelect(opt),
              child: Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: sel ? const Color(0xFFE8F0FE) : Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: sel ? const Color(0xFF1A73E8) : const Color(0xFFE8EAED), width: sel ? 2 : 1),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(opt, style: TextStyle(fontSize: 13, fontWeight: sel ? FontWeight.w700 : FontWeight.w500, color: sel ? const Color(0xFF1A73E8) : const Color(0xFF202124))),
                    if (sel) const Icon(Icons.check_circle, color: Color(0xFF1A73E8), size: 18),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    ],
  );
}
