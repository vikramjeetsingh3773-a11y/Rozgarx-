import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class StudyPlanScreen extends StatefulWidget {
  const StudyPlanScreen({super.key});
  @override
  State<StudyPlanScreen> createState() => _StudyPlanScreenState();
}

class _StudyPlanScreenState extends State<StudyPlanScreen> with SingleTickerProviderStateMixin {
  late TabController _tabCtrl;

  final _subjects = [
    {'name': 'General Intelligence', 'emoji': '🧠', 'progress': 0.6, 'topics': 24, 'done': 14},
    {'name': 'General Awareness', 'emoji': '📰', 'progress': 0.4, 'topics': 30, 'done': 12},
    {'name': 'Quantitative Aptitude', 'emoji': '📊', 'progress': 0.3, 'topics': 28, 'done': 9},
    {'name': 'English Comprehension', 'emoji': '📚', 'progress': 0.7, 'topics': 20, 'done': 14},
  ];

  final _dailyTasks = [
    {'title': 'Current Affairs', 'duration': '30 min', 'emoji': '📰', 'done': true},
    {'title': 'Reasoning Practice', 'duration': '45 min', 'emoji': '🧠', 'done': true},
    {'title': 'Maths Problems', 'duration': '1 hour', 'emoji': '📊', 'done': false},
    {'title': 'English Reading', 'duration': '30 min', 'emoji': '📚', 'done': false},
    {'title': 'Mock Test', 'duration': '2 hours', 'emoji': '📝', 'done': false},
  ];

  @override
  void initState() {
    super.initState();
    _tabCtrl = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() { _tabCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        backgroundColor: Colors.white, elevation: 0,
        title: const Text('Preparation', style: TextStyle(color: Color(0xFF202124), fontSize: 16, fontWeight: FontWeight.w700)),
        actions: [
          IconButton(
            icon: const Icon(Icons.star_outline, color: Color(0xFFF9AB00)),
            onPressed: () => context.push('/premium'),
          ),
        ],
        bottom: TabBar(
          controller: _tabCtrl,
          labelColor: const Color(0xFF1A73E8),
          unselectedLabelColor: const Color(0xFF9AA0A6),
          indicatorColor: const Color(0xFF1A73E8),
          tabs: const [Tab(text: 'Study Plan'), Tab(text: 'Progress')],
        ),
      ),
      body: TabBarView(controller: _tabCtrl, children: [
        _StudyPlanTab(dailyTasks: _dailyTasks),
        _ProgressTab(subjects: _subjects),
      ]),
    );
  }
}

class _StudyPlanTab extends StatefulWidget {
  final List<Map<String, dynamic>> dailyTasks;
  const _StudyPlanTab({required this.dailyTasks});
  @override
  State<_StudyPlanTab> createState() => _StudyPlanTabState();
}

class _StudyPlanTabState extends State<_StudyPlanTab> {
  late List<Map<String, dynamic>> tasks;
  @override
  void initState() { super.initState(); tasks = List.from(widget.dailyTasks); }

  @override
  Widget build(BuildContext context) {
    final done = tasks.where((t) => t['done'] == true).length;
    return SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1A73E8), Color(0xFF0D47A1)]), borderRadius: BorderRadius.circular(12)), child: Column(children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text("Today's Goal", style: TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 4),
            Text('$done/${tasks.length} tasks done', style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
          ]),
          Text('${(done/tasks.length*100).toInt()}%', style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900)),
        ]),
        const SizedBox(height: 12),
        ClipRRect(borderRadius: BorderRadius.circular(4), child: LinearProgressIndicator(value: done/tasks.length, backgroundColor: Colors.white30, color: Colors.white, minHeight: 6)),
      ])),
      const SizedBox(height: 20),
      const Text("Today's Tasks", style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Color(0xFF202124))),
      const SizedBox(height: 10),
      ...tasks.asMap().entries.map((e) {
        final i = e.key; final task = e.value;
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFFE8EAED))),
          child: ListTile(
            leading: Text(task['emoji'] as String, style: const TextStyle(fontSize: 24)),
            title: Text(task['title'] as String, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, decoration: task['done'] == true ? TextDecoration.lineThrough : null, color: task['done'] == true ? const Color(0xFF9AA0A6) : const Color(0xFF202124))),
            subtitle: Text(task['duration'] as String, style: const TextStyle(fontSize: 11, color: Color(0xFF5F6368))),
            trailing: GestureDetector(
              onTap: () => setState(() => tasks[i] = {...task, 'done': !(task['done'] as bool)}),
              child: Container(width: 24, height: 24, decoration: BoxDecoration(shape: BoxShape.circle, color: task['done'] == true ? const Color(0xFF34A853) : Colors.white, border: Border.all(color: task['done'] == true ? const Color(0xFF34A853) : const Color(0xFFE8EAED), width: 2)),
                child: task['done'] == true ? const Icon(Icons.check, color: Colors.white, size: 14) : null),
            ),
          ),
        );
      }),
    ]));
  }
}

class _ProgressTab extends StatelessWidget {
  final List<Map<String, dynamic>> subjects;
  const _ProgressTab({required this.subjects});
  @override
  Widget build(BuildContext context) => SingleChildScrollView(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('Subject Progress', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Color(0xFF202124))),
    const SizedBox(height: 12),
    ...subjects.map((s) => Container(margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFFE8EAED))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        Row(children: [Text(s['emoji'] as String, style: const TextStyle(fontSize: 20)), const SizedBox(width: 8), Text(s['name'] as String, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Color(0xFF202124)))]),
        Text('${s['done']}/${s['topics']} topics', style: const TextStyle(fontSize: 11, color: Color(0xFF5F6368))),
      ]),
      const SizedBox(height: 8),
      ClipRRect(borderRadius: BorderRadius.circular(4), child: LinearProgressIndicator(value: s['progress'] as double, backgroundColor: const Color(0xFFE8EAED), color: const Color(0xFF1A73E8), minHeight: 6)),
      const SizedBox(height: 4),
      Text('${((s['progress'] as double)*100).toInt()}% complete', style: const TextStyle(fontSize: 10, color: Color(0xFF5F6368))),
    ]))),
  ]));
}
