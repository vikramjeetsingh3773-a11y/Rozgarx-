import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class PremiumScreen extends StatefulWidget {
  const PremiumScreen({super.key});
  @override
  State<PremiumScreen> createState() => _PremiumScreenState();
}

class _PremiumScreenState extends State<PremiumScreen> {
  int _selectedPlan = 1;
  final _plans = [
    {'id': 'monthly', 'name': 'Monthly', 'price': '₹99', 'period': '/month', 'save': ''},
    {'id': 'quarterly', 'name': 'Quarterly', 'price': '₹249', 'period': '/3 months', 'save': 'Save 16%'},
    {'id': 'yearly', 'name': 'Yearly', 'price': '₹799', 'period': '/year', 'save': 'Best Value 🔥'},
  ];

  final _benefits = [
    ['🔔', 'Instant job alerts', 'Get notified before anyone else'],
    ['📊', 'AI competition analysis', 'Know your winning chances'],
    ['📄', 'AI application review', 'Personalized feedback'],
    ['📚', 'Complete study plans', 'Tailored preparation roadmap'],
    ['📋', 'All job details', 'No locked sections'],
    ['⬇️', 'Offline access', 'Save jobs without internet'],
    ['🚫', 'No ads ever', 'Clean, distraction-free experience'],
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      body: CustomScrollView(slivers: [
        SliverAppBar(
          expandedHeight: 200, pinned: true,
          leading: IconButton(icon: const Icon(Icons.arrow_back, color: Colors.white), onPressed: () => context.pop()),
          flexibleSpace: FlexibleSpaceBar(
            background: Container(
              decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF1A73E8), Color(0xFF0D47A1)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
              child: const SafeArea(child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                SizedBox(height: 32),
                Text('⭐', style: TextStyle(fontSize: 40)),
                SizedBox(height: 8),
                Text('RozgarX Premium', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w800)),
                SizedBox(height: 4),
                Text('Unlock your full potential', style: TextStyle(color: Colors.white70, fontSize: 13)),
              ]))),
            ),
          ),
        ),
        SliverToBoxAdapter(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('What you get', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Color(0xFF202124))),
          const SizedBox(height: 12),
          ..._benefits.map((b) => Padding(padding: const EdgeInsets.only(bottom: 10), child: Row(children: [
            Container(width: 36, height: 36, decoration: BoxDecoration(color: const Color(0xFFE8F0FE), borderRadius: BorderRadius.circular(8)), child: Center(child: Text(b[0], style: const TextStyle(fontSize: 16)))),
            const SizedBox(width: 12),
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(b[1], style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Color(0xFF202124))),
              Text(b[2], style: const TextStyle(fontSize: 11, color: Color(0xFF5F6368))),
            ]),
          ]))),
          const SizedBox(height: 20),
          const Text('Choose Your Plan', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Color(0xFF202124))),
          const SizedBox(height: 12),
          ...List.generate(_plans.length, (i) {
            final plan = _plans[i];
            final sel = i == _selectedPlan;
            return GestureDetector(
              onTap: () => setState(() => _selectedPlan = i),
              child: Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: sel ? const Color(0xFFE8F0FE) : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: sel ? const Color(0xFF1A73E8) : const Color(0xFFE8EAED), width: sel ? 2 : 1),
                ),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  Row(children: [
                    Container(width: 20, height: 20, decoration: BoxDecoration(shape: BoxShape.circle, color: sel ? const Color(0xFF1A73E8) : Colors.white, border: Border.all(color: sel ? const Color(0xFF1A73E8) : const Color(0xFFE8EAED), width: 2)),
                      child: sel ? const Icon(Icons.check, color: Colors.white, size: 12) : null),
                    const SizedBox(width: 12),
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(plan['name']!, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: sel ? const Color(0xFF1A73E8) : const Color(0xFF202124))),
                      if (plan['save']!.isNotEmpty) Text(plan['save']!, style: const TextStyle(fontSize: 10, color: Color(0xFF34A853), fontWeight: FontWeight.w600)),
                    ]),
                  ]),
                  Row(children: [
                    Text(plan['price']!, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: sel ? const Color(0xFF1A73E8) : const Color(0xFF202124))),
                    Text(plan['period']!, style: const TextStyle(fontSize: 10, color: Color(0xFF5F6368))),
                  ]),
                ]),
              ),
            );
          }),
          const SizedBox(height: 20),
          SizedBox(width: double.infinity, child: ElevatedButton(
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('In-app purchase — configure in Play Console'))),
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1A73E8), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            child: Text('Subscribe ${_plans[_selectedPlan]['price']} ${_plans[_selectedPlan]['period']}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
          )),
          const SizedBox(height: 12),
          const Center(child: Text('Cancel anytime • Secure payment via Google Pay / UPI', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Color(0xFF9AA0A6)))),
          const SizedBox(height: 30),
        ]))),
      ]),
    );
  }
}
