import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:go_router/go_router.dart';
import '../../../shared/models/job_model.dart';
import '../../../features/jobs/widgets/job_card.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    final name = user?.displayName?.split(' ').first ?? 'Aspirant';

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              floating: true, backgroundColor: Colors.white, elevation: 0,
              title: Row(children: [
                Container(
                  width: 32, height: 32,
                  decoration: BoxDecoration(color: const Color(0xFF1A73E8), borderRadius: BorderRadius.circular(8)),
                  child: const Center(child: Text('RX', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 10))),
                ),
                const SizedBox(width: 8),
                const Text('RozgarX AI', style: TextStyle(color: Color(0xFF202124), fontWeight: FontWeight.w700, fontSize: 16)),
              ]),
              actions: [
                IconButton(icon: const Icon(Icons.notifications_outlined, color: Color(0xFF202124)), onPressed: () {}),
                IconButton(
                  icon: const Icon(Icons.search, color: Color(0xFF202124)),
                  onPressed: () => showSearch(context: context, delegate: _JobSearchDelegate()),
                ),
              ],
            ),
            SliverToBoxAdapter(
              child: Container(
                color: Colors.white,
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Good morning, $name 👋', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Color(0xFF202124))),
                  const SizedBox(height: 2),
                  const Text("Here's what's new today", style: TextStyle(fontSize: 13, color: Color(0xFF5F6368))),
                ]),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(children: [
                  _StatCard(emoji: '⏰', value: '5', label: 'Closing Soon', color: const Color(0xFFEA4335)),
                  const SizedBox(width: 8),
                  _StatCard(emoji: '🆕', value: '12', label: 'New Today', color: const Color(0xFF1A73E8)),
                  const SizedBox(width: 8),
                  _StatCard(emoji: '⭐', value: 'Free', label: 'Your Plan', color: const Color(0xFFF9AB00)),
                ]),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('⏰ Closing Soon', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: Color(0xFF202124))),
                  GestureDetector(onTap: () => context.go('/jobs'), child: const Text('See all', style: TextStyle(color: Color(0xFF1A73E8), fontWeight: FontWeight.w600, fontSize: 12))),
                ]),
              ),
            ),
            StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('jobs')
                  .where('isActive', isEqualTo: true)
                  .where('applicationEnd', isGreaterThanOrEqualTo: Timestamp.now())
                  .orderBy('applicationEnd')
                  .limit(10)
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const SliverToBoxAdapter(child: Center(child: Padding(padding: EdgeInsets.all(32), child: CircularProgressIndicator())));
                }
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  return SliverToBoxAdapter(child: _EmptyState());
                }
                final jobs = snapshot.data!.docs.map((d) => JobModel.fromFirestore(d)).toList();
                return SliverList(delegate: SliverChildBuilderDelegate(
                  (c, i) => Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
                    child: JobCard(job: jobs[i], onTap: () => context.go('/jobs/${jobs[i].id}')),
                  ),
                  childCount: jobs.length,
                ));
              },
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 20)),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String emoji, value, label; final Color color;
  const _StatCard({required this.emoji, required this.value, required this.label, required this.color});
  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: color.withOpacity(0.08), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.2))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(emoji, style: const TextStyle(fontSize: 18)),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: color)),
        Text(label, style: TextStyle(fontSize: 9, fontWeight: FontWeight.w500, color: color)),
      ]),
    ),
  );
}

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) => const Center(
    child: Padding(
      padding: EdgeInsets.all(32),
      child: Column(children: [
        Text('📋', style: TextStyle(fontSize: 48)),
        SizedBox(height: 12),
        Text('No jobs yet', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
        SizedBox(height: 4),
        Text('Jobs will appear here once added', style: TextStyle(color: Color(0xFF5F6368), fontSize: 13)),
      ]),
    ),
  );
}

class _JobSearchDelegate extends SearchDelegate<String> {
  @override
  List<Widget> buildActions(BuildContext context) => [IconButton(icon: const Icon(Icons.clear), onPressed: () => query = '')];
  @override
  Widget buildLeading(BuildContext context) => IconButton(icon: const Icon(Icons.arrow_back), onPressed: () => close(context, ''));
  @override
  Widget buildResults(BuildContext context) => _buildSearch(context);
  @override
  Widget buildSuggestions(BuildContext context) => _buildSearch(context);

  Widget _buildSearch(BuildContext context) {
    if (query.isEmpty) return const Center(child: Text('Type to search jobs...'));
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('jobs').where('isActive', isEqualTo: true).snapshots(),
      builder: (c, snap) {
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final q = query.toLowerCase();
        final jobs = snap.data!.docs
            .map((d) => JobModel.fromFirestore(d))
            .where((j) => j.title.toLowerCase().contains(q) || j.organization.toLowerCase().contains(q))
            .toList();
        if (jobs.isEmpty) return Center(child: Text('No jobs found for "$query"'));
        return ListView.builder(
          padding: const EdgeInsets.all(12),
          itemCount: jobs.length,
          itemBuilder: (c, i) => JobCard(job: jobs[i], onTap: () { close(context, ''); context.go('/jobs/${jobs[i].id}'); }),
        );
      },
    );
  }
}
