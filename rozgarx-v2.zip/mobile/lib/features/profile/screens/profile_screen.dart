import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:go_router/go_router.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        backgroundColor: Colors.white, elevation: 0,
        title: const Text('Profile', style: TextStyle(color: Color(0xFF202124), fontSize: 16, fontWeight: FontWeight.w700)),
        actions: [
          IconButton(icon: const Icon(Icons.settings_outlined, color: Color(0xFF202124)), onPressed: () {}),
        ],
      ),
      body: SingleChildScrollView(child: Column(children: [
        Container(color: Colors.white, padding: const EdgeInsets.all(20), child: Column(children: [
          CircleAvatar(
            radius: 36, backgroundColor: const Color(0xFF1A73E8),
            child: Text(user?.displayName?.isNotEmpty == true ? user!.displayName![0].toUpperCase() : 'A', style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w700)),
          ),
          const SizedBox(height: 12),
          Text(user?.displayName ?? 'Aspirant', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Color(0xFF202124))),
          const SizedBox(height: 2),
          Text(user?.email ?? '', style: const TextStyle(fontSize: 12, color: Color(0xFF5F6368))),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
            decoration: BoxDecoration(color: const Color(0xFFE8F0FE), borderRadius: BorderRadius.circular(20)),
            child: const Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.star, color: Color(0xFFF9AB00), size: 14),
              SizedBox(width: 4),
              Text('Free Plan', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Color(0xFF1A73E8))),
            ]),
          ),
        ])),
        const SizedBox(height: 8),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 16),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF1A73E8), Color(0xFF0D47A1)]), borderRadius: BorderRadius.circular(12)),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Upgrade to Premium', style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w700)),
              SizedBox(height: 2),
              Text('Unlock all features from ₹99/month', style: TextStyle(color: Colors.white70, fontSize: 11)),
            ]),
            ElevatedButton(
              onPressed: () => context.push('/premium'),
              style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: const Color(0xFF1A73E8), padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
              child: const Text('Upgrade', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            ),
          ]),
        ),
        const SizedBox(height: 8),
        Container(color: Colors.white, child: Column(children: [
          _ProfileRow(icon: Icons.work_outline, title: 'Saved Jobs', onTap: () {}),
          _ProfileRow(icon: Icons.notifications_outlined, title: 'Notifications', onTap: () {}),
          _ProfileRow(icon: Icons.person_outline, title: 'Edit Profile', onTap: () {}),
          _ProfileRow(icon: Icons.help_outline, title: 'Help & Support', onTap: () {}),
          _ProfileRow(icon: Icons.privacy_tip_outlined, title: 'Privacy Policy', onTap: () {}),
          _ProfileRow(icon: Icons.info_outline, title: 'About RozgarX AI', onTap: () {}),
        ])),
        const SizedBox(height: 8),
        Container(color: Colors.white, child: _ProfileRow(
          icon: Icons.logout,
          title: 'Sign Out',
          color: const Color(0xFFEA4335),
          onTap: () async {
            await FirebaseAuth.instance.signOut();
            if (context.mounted) context.go('/login');
          },
        )),
        const SizedBox(height: 8),
        FutureBuilder<DocumentSnapshot>(
          future: FirebaseFirestore.instance.collection('users').doc(user?.uid).get(),
          builder: (c, snap) {
            if (!snap.hasData) return const SizedBox();
            final data = snap.data?.data() as Map<String, dynamic>?;
            if (data == null) return const SizedBox();
            return Container(color: Colors.white, padding: const EdgeInsets.all(16), margin: const EdgeInsets.symmetric(horizontal: 0), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Your Profile', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: Color(0xFF202124))),
              const SizedBox(height: 10),
              if (data['education'] != null) _InfoRow('Education', data['education'] as String),
              if (data['targetExam'] != null) _InfoRow('Target Exam', data['targetExam'] as String),
              if (data['state'] != null) _InfoRow('State', data['state'] as String),
            ]));
          },
        ),
        const SizedBox(height: 20),
        const Text('RozgarX AI v1.0.0', style: TextStyle(fontSize: 11, color: Color(0xFF9AA0A6))),
        const SizedBox(height: 20),
      ])),
    );
  }
}

class _ProfileRow extends StatelessWidget {
  final IconData icon; final String title; final VoidCallback onTap; final Color? color;
  const _ProfileRow({required this.icon, required this.title, required this.onTap, this.color});
  @override
  Widget build(BuildContext context) => ListTile(
    leading: Icon(icon, color: color ?? const Color(0xFF5F6368), size: 20),
    title: Text(title, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500, color: color ?? const Color(0xFF202124))),
    trailing: const Icon(Icons.chevron_right, color: Color(0xFF9AA0A6), size: 18),
    onTap: onTap,
  );
}

class _InfoRow extends StatelessWidget {
  final String label, value;
  const _InfoRow(this.label, this.value);
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Row(children: [
    SizedBox(width: 100, child: Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFF5F6368)))),
    Text(value, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Color(0xFF202124))),
  ]));
}
